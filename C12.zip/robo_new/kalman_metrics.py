import cv2
import numpy as np
import socket
import json
import time
import pyttsx3
from ultralytics import YOLO
import threading
import queue
import pandas as pd
from uuid import uuid4

# Initialize stop event
stop_event = threading.Event()

# Visualization enabled
ENABLE_VISUALIZATION = True

# Refined HSV for yellow T-shirt
HSV_LOWER = np.array([20, 100, 120])
HSV_UPPER = np.array([30, 255, 255])

PI_IP = "192.168.142.130"
PI_PORT = 65432

# Camera setup
STREAM_URL = 'http://192.168.142.130:8080/?action=stream'
cap = cv2.VideoCapture(STREAM_URL, cv2.CAP_FFMPEG)
if not cap.isOpened():
    print("Error: Could not open video stream")
    exit()

# Camera settings
cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 416)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 312)
cap.set(cv2.CAP_PROP_FPS, 20)

# Initialize YOLOv8
model = YOLO("yolov8n.pt")

# Initialize KCF tracker
tracker = None
tracker_active = False
tracker_confidence = 0.0

# Initialize pyttsx3
engine = pyttsx3.init()
engine.setProperty('rate', 150)

# Thread-safe queue for YOLO results
yolo_queue = queue.Queue(maxsize=1)

# Metrics logging
metrics_log = []
frame_times = []
positions = []  # For jerk calculation
commands = []  # For command stability
log_file = f"metrics_{uuid4()}.csv"

# Simulated ground truth for IoU (replace with actual annotations)
# Format: {frame_number: (x, y, w, h)}
ground_truth = {
    0: (150, 100, 80, 120),
    100: (160, 110, 80, 120),
    200: (155, 105, 80, 120),
    # Add more as needed
}

# Optimized Kalman Filter
class KalmanFilter:
    def __init__(self, dt=0.05):
        self.dt = dt
        self.F = np.array([
            [1, 0, dt, 0],
            [0, 1, 0, dt],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ])
        self.H = np.array([
            [1, 0, 0, 0],
            [0, 1, 0, 0]
        ])
        self.Q = np.eye(4) * 0.005
        self.R = np.array([
            [5, 0],
            [0, 5]
        ])
        self.x = np.zeros((4, 1))
        self.P = np.eye(4) * 5

    def predict(self):
        self.x = self.F @ self.x
        self.P = self.F @ self.P @ self.F.T + self.Q
        return self.x[:2].flatten()

    def update(self, z):
        z = np.array(z).reshape(-1, 1)
        y = z - self.H @ self.x
        S = self.H @ self.P @ self.H.T + self.R
        K = self.P @ self.H.T @ np.linalg.inv(S)
        self.x = self.x + K @ y
        self.P = (np.eye(4) - K @ self.H) @ self.P
        return self.x[:2].flatten()

# PID Controller
class PIDController:
    def __init__(self, Kp=0.6, Ki=0.002, Kd=0.08):
        self.Kp = Kp
        self.Ki = Ki
        self.Kd = Kd
        self.prev_error = 0
        self.integral = 0
        self.last_time = time.time()

    def compute(self, error):
        current_time = time.time()
        dt = current_time - self.last_time
        self.last_time = current_time
        self.integral += error * dt
        derivative = (error - self.prev_error) / dt if dt > 0 else 0
        output = self.Kp * error + self.Ki * self.integral + self.Kd * derivative
        self.prev_error = error
        return output

def calculate_iou(box1, box2):
    """Calculate IoU between two bounding boxes (x, y, w, h)."""
    x1, y1, w1, h1 = box1
    x2, y2, w2, h2 = box2
    
    xi1 = max(x1, x2)
    yi1 = max(y1, y2)
    xi2 = min(x1 + w1, x2 + w2)
    yi2 = min(y1 + h1, y2 + h2)
    
    inter_area = max(0, xi2 - xi1) * max(0, yi2 - yi1)
    box1_area = w1 * h1
    box2_area = w2 * h2
    union_area = box1_area + box2_area - inter_area
    
    return inter_area / union_area if union_area > 0 else 0

def send_motor_command(action, speed=None):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.3)
            s.connect((PI_IP, PI_PORT))
            cmd = {"action": action}
            if speed is not None:
                cmd["speed"] = speed
            s.sendall((json.dumps(cmd) + '\n').encode())
            response = s.recv(1024).decode()
            return response == "ACK"
    except Exception as e:
        print(f"Socket error: {e}")
        return False

# Speak with cooldown
last_speak_time = 0
speak_cooldown = 5
def speak(text):
    global last_speak_time
    current_time = time.time()
    if current_time - last_speak_time >= speak_cooldown:
        try:
            engine.say(text)
            engine.runAndWait()
            last_speak_time = current_time
        except Exception as e:
            print(f"Audio error: {e}")

# Bounding box smoothing
def smooth_bbox(new_bbox, prev_bbox, alpha=0.4):
    if not new_bbox:
        return prev_bbox
    if not prev_bbox:
        return new_bbox
    x1, y1, w1, h1 = new_bbox
    x2, y2, w2, h2 = prev_bbox
    x = int(alpha * x1 + (1 - alpha) * x2)
    y = int(alpha * y1 + (1 - alpha) * y2)
    w = int(alpha * w1 + (1 - alpha) * w2)
    h = int(alpha * h1 + (1 - alpha) * h2)
    return (x, y, w, h)

# Validate bounding box
def is_valid_bbox(bbox, frame_shape):
    if bbox is None:
        return False
    x, y, w, h = bbox
    if w < 10 or h < 10 or w > frame_shape[1] * 0.8 or h > frame_shape[0] * 0.8:
        return False
    if x < 0 or y < 0 or x + w > frame_shape[1] or y + h > frame_shape[0]:
        return False
    return True

# YOLO processing thread
def yolo_thread(frame_queue, result_queue, stop_event):
    while not stop_event.is_set():
        try:
            frame = frame_queue.get(timeout=0.5)
            results = model(frame, classes=[0], conf=0.4, verbose=False, imgsz=320)
            yolo_bbox = None
            max_conf = 0
            for result in results:
                boxes = result.boxes
                for box in boxes:
                    conf = box.conf.item()
                    if conf > max_conf:
                        x, y, w, h = box.xywh[0].cpu().numpy()
                        x = int(x - w / 2)
                        y = int(y - h / 2)
                        w, h = int(w), int(h)
                        y = int(y + 0.2 * h)
                        h = int(0.6 * h)
                        yolo_bbox = (x, y, w, h)
                        max_conf = conf
            try:
                result_queue.put_nowait((yolo_bbox, max_conf))
            except queue.Full:
                pass
            frame_queue.task_done()
        except queue.Empty:
            continue
        except Exception as e:
            print(f"YOLO thread error: {e}")

# Get latest frame
def get_latest_frame(cap, max_attempts=5):
    latest_frame = None
    ret = False
    for _ in range(max_attempts):
        ret, frame = cap.read()
        if ret:
            latest_frame = frame
        else:
            break
    return ret, latest_frame

# Main loop
try:
    if ENABLE_VISUALIZATION:
        cv2.namedWindow("Frame", cv2.WINDOW_NORMAL)
        cv2.moveWindow("Frame", 100, 100)
        cv2.startWindowThread()

    # Initialize controllers
    kf = KalmanFilter(dt=0.05)
    pid_x = PIDController(Kp=0.6, Ki=0.002, Kd=0.08)
    pid_distance = PIDController(Kp=0.3, Ki=0.001, Kd=0.02)

    # Speed parameters
    MIN_TURN_SPEED = 55
    MAX_TURN_SPEED = 85
    BASE_SPEED = 55
    TURN_THRESHOLD = 0.08

    # Tracking variables
    last_time = time.time()
    frame_count = 0
    fps = 0
    no_person_time = None
    rotating = False
    rotation_start = None
    last_yolo_time = 0
    tracking_state = False
    prev_bbox = None
    miss_count = 0
    miss_threshold = 15
    last_command = None
    stable_tracking = False
    tracking_confidence = 0.0
    frame_number = 0
    tracking_success = 0

    # Start YOLO thread
    frame_queue = queue.Queue(maxsize=1)
    yolo_thread = threading.Thread(target=yolo_thread, args=(frame_queue, yolo_queue, stop_event))
    yolo_thread.daemon = True
    yolo_thread.start()

    while True:
        start_time = time.time()
        ret, frame = get_latest_frame(cap)
        if not ret:
            print("Failed to grab frame")
            time.sleep(0.01)
            continue

        # FPS calculation
        frame_count += 1
        current_time = time.time()
        if current_time - last_time >= 1.0:
            fps = frame_count / (current_time - last_time)
            frame_count = 0
            last_time = current_time

        # Initialize bbox and tracking source
        bbox = None
        tracking_source = None
        current_confidence = 0.0

        # KCF tracking
        if tracker_active:
            success, kcf_bbox = tracker.update(frame)
            if success and is_valid_bbox(kcf_bbox, frame.shape):
                x, y, w, h = [int(v) for v in kcf_bbox]
                bbox = (x, y, w, h)
                tracking_source = "KCF"
                current_confidence = tracker_confidence * 0.9
                tracker_confidence = current_confidence

        # YOLO processing
        yolo_interval = 0.3 if stable_tracking else 0.1
        if current_time - last_yolo_time >= yolo_interval:
            try:
                frame_queue.put_nowait(frame.copy())
                last_yolo_time = current_time
            except queue.Full:
                pass

        # Check YOLO results
        yolo_bbox = None
        yolo_conf = 0.0
        try:
            yolo_bbox, yolo_conf = yolo_queue.get_nowait()
            yolo_queue.task_done()
        except queue.Empty:
            pass

        # HSV tracking
        if yolo_bbox and is_valid_bbox(yolo_bbox, frame.shape) and (not bbox or current_confidence < yolo_conf):
            x, y, w, h = yolo_bbox
            roi = frame[max(0,y-30):y+h+30, max(0,x-30):x+w+30]
            if roi.size > 0:
                roi = cv2.resize(roi, (64, 64))
                hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
                mask = cv2.inRange(hsv, HSV_LOWER, HSV_UPPER)
                kernel = np.ones((5,5), np.uint8)
                mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
                mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
                contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                if contours:
                    largest_contour = max(contours, key=cv2.contourArea)
                    if cv2.contourArea(largest_contour) > 30:
                        hx, hy, hw, hh = cv2.boundingRect(largest_contour)
                        scale_x = (w + 60) / 64
                        scale_y = (h + 60) / 64
                        hx = int(hx * scale_x + max(0, x-30))
                        hy = int(hy * scale_y + max(0, y-30))
                        hw = int(hw * scale_x)
                        hh = int(hh * scale_y)
                        if is_valid_bbox((hx, hy, hw, hh), frame.shape):
                            bbox = (hx, hy, hw, hh)
                            tracking_source = "HSV"
                            current_confidence = yolo_conf * 0.95
                            if not tracker_active or current_confidence > tracker_confidence:
                                tracker = cv2.TrackerKCF_create()
                                tracker.init(frame, (hx, hy, hw, hh))
                                tracker_active = True
                                tracker_confidence = current_confidence
                    else:
                        bbox = yolo_bbox
                        tracking_source = "YOLO"
                        current_confidence = yolo_conf
                        if not tracker_active or current_confidence > tracker_confidence:
                            tracker = cv2.TrackerKCF_create()
                            tracker.init(frame, yolo_bbox)
                            tracker_active = True
                            tracker_confidence = yolo_conf

        # Fallback to YOLO
        if yolo_bbox and is_valid_bbox(yolo_bbox, frame.shape) and not bbox:
            bbox = yolo_bbox
            tracking_source = "YOLO"
            current_confidence = yolo_conf
            if not tracker_active or current_confidence > tracker_confidence:
                tracker = cv2.TrackerKCF_create()
                tracker.init(frame, yolo_bbox)
                tracker_active = True
                tracker_confidence = yolo_conf

        # Smooth bbox
        if bbox and is_valid_bbox(bbox, frame.shape):
            bbox = smooth_bbox(bbox, prev_bbox)
            prev_bbox = bbox
            miss_count = 0
            tracking_confidence = max(tracking_confidence, current_confidence)
            stable_tracking = tracking_confidence > 0.75
            tracking_success += 1
        else:
            miss_count += 1
            if miss_count <= miss_threshold and prev_bbox:
                bbox = prev_bbox
                tracking_confidence *= 0.85
            else:
                prev_bbox = None
                tracker_active = False
                tracking_confidence = 0.0
                stable_tracking = False

        # Calculate metrics
        iou = 0
        distance_error = 0
        center_x, center_y = frame.shape[1] // 2, frame.shape[0] // 2

        if bbox and is_valid_bbox(bbox, frame.shape):
            x, y, w, h = bbox
            center = np.array([x + w/2, y + h/2])
            predicted = kf.predict()
            smoothed_center = kf.update(center)
            center_x, center_y = smoothed_center

            # Calculate IoU if ground truth exists
            if frame_number in ground_truth:
                iou = calculate_iou(bbox, ground_truth[frame_number])

            # Calculate distance error
            target_center = (frame.shape[1] // 2, frame.shape[0] // 2)
            distance_error = np.sqrt((center_x - target_center[0])**2 + (center_y - target_center[1])**2)

            # Store position for jerk calculation
            positions.append((center_x, center_y))

            # Proportional control calculations
            frame_center_x = frame.shape[1] / 2
            error_x = (center_x - frame_center_x) / frame_center_x
            target_distance = frame.shape[1] * 0.3
            error_distance = (w - target_distance) / target_distance
            
            # Calculate adjustments
            turn_adjustment = pid_x.compute(error_x)
            speed_adjustment = pid_distance.compute(error_distance)
            
            # Movement decision
            if abs(error_x) > TURN_THRESHOLD:
                turn_speed = int(np.clip(
                    MIN_TURN_SPEED + abs(error_x) * (MAX_TURN_SPEED - MIN_TURN_SPEED),
                    MIN_TURN_SPEED, MAX_TURN_SPEED
                ))
                action = "right" if error_x > 0 else "left"
                speed = turn_speed
            else:
                forward_speed = int(np.clip(BASE_SPEED + speed_adjustment * 30, 30, 85))
                action = "forward"
                speed = forward_speed

            # Log command for stability analysis
            commands.append((action, speed))

            # Visualization
            if ENABLE_VISUALIZATION:
                color = (0, 255, 0) if tracking_source in ["HSV", "KCF"] else (255, 0, 0)
                cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)
                cv2.circle(frame, (int(center_x), int(center_y)), 5, (0, 0, 255), -1)
                cv2.putText(frame, f"FPS: {fps:.1f}", (10, 20),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(frame, f"State: {'Tracked' if tracking_state else 'Searching'}", (10, 50),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(frame, f"Source: {tracking_source or 'None'}", (10, 80),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(frame, f"Conf: {tracking_confidence:.2f}", (10, 110),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(frame, f"Action: {action} {speed}", (10, 140),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(frame, f"ErrorX: {error_x:.2f}", (10, 170),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(frame, f"IoU: {iou:.2f}", (10, 200),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(frame, f"DistErr: {distance_error:.1f}", (10, 230),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.imshow("Frame", frame)

            if not tracking_state:
                speak("Following person in yellow")
                tracking_state = True

            no_person_time = None
            rotating = False

            # Send command
            if last_command != (action, speed):
                send_motor_command(action, speed)
                last_command = (action, speed)

        else:
            if no_person_time is None and miss_count > miss_threshold:
                no_person_time = current_time
                rotation_start = current_time
                if tracking_state:
                    speak("Searching for person in yellow")
                    tracking_state = False
                send_motor_command("right", 30)
                last_command = ("right", 30)
                rotating = True
                commands.append(("right", 30))
            elif rotating and current_time - rotation_start >= 8:
                send_motor_command("stop")
                last_command = ("stop", None)
                no_person_time = None
                rotating = False
                commands.append(("stop", None))
                if not tracking_state:
                    speak("Searching for person in yellow")
            elif not rotating and miss_count > miss_threshold:
                send_motor_command("stop")
                last_command = ("stop", None)
                commands.append(("stop", None))

        # Calculate latency
        latency = (time.time() - start_time) * 1000  # in ms
        frame_times.append(latency)

        # Log metrics
        metrics_log.append({
            "frame": frame_number,
            "fps": fps,
            "latency_ms": latency,
            "iou": iou,
            "distance_error": distance_error,
            "center_x": center_x,
            "center_y": center_y,
            "tracking_success": 1 if bbox and is_valid_bbox(bbox, frame.shape) else 0
        })

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        frame_number += 1

except KeyboardInterrupt:
    print("Shutting down...")
except Exception as e:
    print(f"Error: {e}")
finally:
    stop_event.set()
    send_motor_command("stop")
    cap.release()
    if ENABLE_VISUALIZATION:
        cv2.destroyAllWindows()
    engine.stop()

    # Save metrics to CSV
    metrics_df = pd.DataFrame(metrics_log)
    metrics_df.to_csv(log_file, index=False)

    # Calculate jerk
    if len(positions) > 3:
        dt = 1 / fps if fps > 0 else 0.033
        positions = np.array(positions)
        velocity = np.diff(positions, axis=0) / dt
        acceleration = np.diff(velocity, axis=0) / dt
        jerk = np.diff(acceleration, axis=0) / dt
        jerk_magnitude = np.mean(np.sqrt(jerk[:, 0]**2 + jerk[:, 1]**2))
    else:
        jerk_magnitude = 0

    # Calculate command stability (number of command changes)
    command_changes = 0
    for i in range(1, len(commands)):
        if commands[i] != commands[i-1]:
            command_changes += 1
    command_stability = command_changes / len(commands) if commands else 0

    # Calculate tracking success rate
    tracking_success_rate = (tracking_success / frame_number) * 100 if frame_number > 0 else 0

    # Print summary
    print("\n=== Evaluation Metrics Summary ===")
    print(f"Total Frames: {frame_number}")
    print(f"Average FPS: {metrics_df['fps'].mean():.2f}")
    print(f"Average Latency: {metrics_df['latency_ms'].mean():.2f} ms")

    print(f"Accuracy: {tracking_success_rate:.2f}%")
