import cv2
import numpy as np
import socket
import json
import time
import mediapipe as mp
from ultralytics import YOLO
import pandas as pd
from uuid import uuid4

# Socket setup
PI_IP = "192.168.142.130"
PI_PORT = 65432

# Camera setup
STREAM_URL = 'http://192.168.142.130:8080/?action=stream'
cap = cv2.VideoCapture(STREAM_URL)
if not cap.isOpened():
    print("Error: Could not open video stream")
    exit()

# Optimize stream
cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)
cap.set(cv2.CAP_PROP_FPS, 15)

# YOLO setup
yolo_model = YOLO("yolov8n.pt")

# MediaPipe Hands setup
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=2, min_detection_confidence=0.5, min_tracking_confidence=0.5)
mp_draw = mp.solutions.drawing_utils

# Obstacle avoidance parameters
OBSTACLE_THRESHOLD = 1000
SAFE_DISTANCE = 80
GRID_ROWS = 3
GRID_COLS = 3

# Metrics logging
metrics_log = []
frame_times = []
commands = []  # For command stability
log_file = f"metrics_{uuid4()}.csv"

# Simulated ground truth (replace with actual annotations)
# Person ground truth: {frame_number: (x, y, w, h)}
person_ground_truth = {
    0: (100, 80, 60, 100),
    100: (110, 85, 60, 100),
    200: (105, 82, 60, 100),
    # Add more as needed
}

# Gesture ground truth: {frame_number: gesture}
gesture_ground_truth = {
    0: "one_open_hand",
    100: "two_open_hands",
    200: "none",
    # Add more as needed
}

# Obstacle ground truth: {frame_number: np.array of shape (height, width) with 255 for obstacles}
obstacle_ground_truth = {
    0: np.zeros((240, 320), dtype=np.uint8),  # No obstacles
    100: np.zeros((240, 320), dtype=np.uint8),  # Placeholder
    200: np.zeros((240, 320), dtype=np.uint8),  # Placeholder
    # Add more as needed
}

def calculate_iou(box1, box2):
    """Calculate IoU between two bounding boxes (x, y, w, h)."""
    x1, y1, w1, h1 = box1
    x2, y2, w2, h2 = box2
    
    xi1 = max(x1, x2)
    yi1 = max(y1, y2)
    xi2 = min(x1 + w1, x2 + w2)
    yi2 = min(y1 + h1, y2 + h2)
    
    inter_area = max(0, xi2 - xi1) * max(0, yi2 - yi1)
    box1_area = w1 * h1
    box2_area = w2 * h2
    union_area = box1_area + box2_area - inter_area
    
    return inter_area / union_area if union_area > 0 else 0

def calculate_obstacle_iou(pred_mask, gt_mask):
    """Calculate IoU for obstacle masks."""
    intersection = np.logical_and(pred_mask, gt_mask).sum()
    union = np.logical_or(pred_mask, gt_mask).sum()
    return intersection / union if union > 0 else 0

def send_motor_command(action, speed=None):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.5)
            s.connect((PI_IP, PI_PORT))
            cmd = {"action": action}
            if speed:
                cmd["speed"] = speed
            s.sendall((json.dumps(cmd) + '\n').encode())
            response = s.recv(1024).decode()
            return response == "ACK"
    except Exception as e:
        print(f"Socket error: {e}")
        return False

def recognize_gesture(landmarks, frame_width):
    wrist = landmarks[0]
    index_tip = landmarks[8]
    middle_tip = landmarks[12]
    ring_tip = landmarks[16]
    pinky_tip = landmarks[20]
    thumb_tip = landmarks[4]

    finger_tips = [index_tip, middle_tip, ring_tip, pinky_tip]
    fingers_up = sum(1 for tip in finger_tips if tip.y < wrist.y - 0.02)
    thumb_up = thumb_tip.y < wrist.y - 0.02

    if fingers_up >= 3 and thumb_up:
        return "open_hand", 0.95
    else:
        return "unknown", 0.5

def clear_buffer(cap):
    for _ in range(5):
        cap.grab()

def estimate_depth(prev_frame, current_frame):
    prev_gray = cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)
    current_gray = cv2.cvtColor(current_frame, cv2.COLOR_BGR2GRAY)
    
    diff = cv2.absdiff(prev_gray, current_gray)
    _, threshold = cv2.threshold(diff, 25, 255, cv2.THRESH_BINARY)
    
    contours, _ = cv2.findContours(threshold, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    
    obstacle_mask = np.zeros_like(threshold)
    for contour in contours:
        if cv2.contourArea(contour) > OBSTACLE_THRESHOLD:
            cv2.drawContours(obstacle_mask, [contour], -1, 255, -1)
    
    return obstacle_mask

def analyze_obstacles(obstacle_mask, grid_rows, grid_cols):
    height, width = obstacle_mask.shape
    grid_height = height // grid_rows
    grid_width = width // grid_cols
    
    grid_obstacles = np.zeros((grid_rows, grid_cols))
    
    for i in range(grid_rows):
        for j in range(grid_cols):
            y_start = i * grid_height
            y_end = (i + 1) * grid_height if i < grid_rows - 1 else height
            x_start = j * grid_width
            x_end = (j + 1) * grid_width if j < grid_cols - 1 else width
            
            grid = obstacle_mask[y_start:y_end, x_start:x_end]
            grid_obstacles[i, j] = np.sum(grid) / 255
            
    return grid_obstacles

def get_safe_direction(grid_obstacles, frame_width):
    grid_rows, grid_cols = grid_obstacles.shape
    
    forward_cols = [grid_cols // 2]
    if grid_cols > 2:
        forward_cols = [grid_cols // 2 - 1, grid_cols // 2, grid_cols // 2 + 1]
    
    for col in forward_cols:
        if np.max(grid_obstacles[:, col]) < SAFE_DISTANCE:
            return "forward"
    
    left_clear = True
    right_clear = True
    
    for col in range(grid_cols // 2):
        if np.max(grid_obstacles[:, col]) >= SAFE_DISTANCE:
            left_clear = False
            break
    
    for col in range(grid_cols // 2 + 1, grid_cols):
        if np.max(grid_obstacles[:, col]) >= SAFE_DISTANCE:
            right_clear = False
            break
    
    if left_clear and right_clear:
        return "left" if frame_width // 2 < grid_cols // 2 else "right"
    elif left_clear:
        return "left"
    elif right_clear:
        return "right"
    else:
        return "stop"

# Main loop
try:
    frame_count = 0
    last_time = time.time()
    fps = 0
    person_confidence = 0.0
    gesture_confidence = 0.0
    follow_mode = False
    skip_frame = False
    prev_frame = None
    frame_number = 0

    while True:
        start_time = time.time()
        
        # Clear buffer
        if frame_count % 5 == 0:
            clear_buffer(cap)

        ret, frame = cap.read()
        if not ret:
            print("Failed to grab frame")
            time.sleep(0.01)
            continue

        # Update FPS
        frame_count += 1
        current_time = time.time()
        if current_time - last_time >= 1.0:
            fps = frame_count / (current_time - last_time)
            frame_count = 0
            last_time = current_time

        # Skip every other frame
        skip_frame = not skip_frame
        if skip_frame:
            prev_frame = frame.copy() if frame is not None else None
            continue

        # Obstacle detection
        obstacle_mask = None
        obstacle_iou = 0
        if prev_frame is not None:
            obstacle_mask = estimate_depth(prev_frame, frame)
            grid_obstacles = analyze_obstacles(obstacle_mask, GRID_ROWS, GRID_COLS)
            safe_direction = get_safe_direction(grid_obstacles, frame.shape[1])
            if frame_number in obstacle_ground_truth:
                obstacle_iou = calculate_obstacle_iou(obstacle_mask, obstacle_ground_truth[frame_number])
        else:
            safe_direction = "forward"
            
        prev_frame = frame.copy()

        # YOLO person detection
        person_bbox = None
        person_confidence = 0.0
        person_iou = 0
        yolo_results = yolo_model(frame, conf=0.4, iou=0.5)

        max_area = 0
        for result in yolo_results:
            for box in result.boxes:
                if int(box.cls) == 0:
                    confidence = box.conf.item()
                    x1, y1, x2, y2 = map(int, box.xyxy[0])
                    w, h = x2 - x1, y2 - y1
                    area = w * h
                    if area > max_area and confidence > 0.4:
                        max_area = area
                        person_bbox = (x1, y1, w, h)
                        person_confidence = confidence
                        if frame_number in person_ground_truth:
                            person_iou = calculate_iou(person_bbox, person_ground_truth[frame_number])

        # MediaPipe hand detection
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        hand_results = hands.process(frame_rgb)
        gesture = "none"
        gesture_confidence = 0.0
        gesture_correct = 0
        confidences = []
        gestures = []

        if hand_results.multi_hand_landmarks and person_bbox:
            x, y, w, h = person_bbox
            for hand_landmarks in hand_results.multi_hand_landmarks:
                wrist = hand_landmarks.landmark[0]
                px, py = int(wrist.x * frame.shape[1]), int(wrist.y * frame.shape[0])
                if x <= px <= x + w and y <= py <= y + h:
                    mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS,
                                        landmark_drawing_spec=mp_draw.DrawingSpec(color=(255, 0, 0), thickness=1),
                                        connection_drawing_spec=mp_draw.DrawingSpec(color=(255, 0, 0), thickness=1))
                    hand_gesture, hand_confidence = recognize_gesture(hand_landmarks.landmark, frame.shape[1])
                    gestures.append(hand_gesture)
                    confidences.append(hand_confidence)

        # Gesture logic
        if confidences:
            gesture_confidence = max(confidences)
        num_hands = len(gestures)

        if num_hands == 1 and gestures[0] == "open_hand":
            follow_mode = True
            gesture = "one_open_hand"
        elif num_hands == 2 and gestures[0] == "open_hand" and gestures[1] == "open_hand":
            follow_mode = False
            gesture = "two_open_hands"
        else:
            gesture = "none" if num_hands == 0 else "unknown"

        if frame_number in gesture_ground_truth:
            gesture_correct = 1 if gesture == gesture_ground_truth[frame_number] else 0

        # Motor control logic with obstacle avoidance
        frame_width = frame.shape[1]
        left_threshold = frame_width // 3
        right_threshold = 2 * frame_width // 3
        distance_error = 0
        action = "stop"
        speed = None

        if follow_mode and person_bbox:
            x, y, w, h = person_bbox
            center_x = x + w // 2

            # Calculate distance error
            target_center = frame_width // 2
            distance_error = abs(center_x - target_center)

            # Draw person bounding box
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 1)
            cv2.putText(frame, f"Person: {person_confidence:.2f}", (x, y - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1)

            # Check obstacle first
            if safe_direction == "stop":
                print("Obstacle detected - Stopping")
                action = "stop"
                send_motor_command("stop")
            else:
                if center_x < left_threshold:
                    if safe_direction == "left" or safe_direction == "forward":
                        print(f"Person ({person_confidence:.2f}) - Turning left")
                        action = "left"
                        speed = 85
                        send_motor_command("left", 85)
                    else:
                        print("Person wants left but obstacle - Adjusting")
                        action = "right"
                        speed = 85
                        send_motor_command("right", 85)
                elif center_x > right_threshold:
                    if safe_direction == "right" or safe_direction == "forward":
                        print(f"Person ({person_confidence:.2f}) - Turning right")
                        action = "right"
                        speed = 85
                        send_motor_command("right", 85)
                    else:
                        print("Person wants right but obstacle - Adjusting")
                        action = "left"
                        speed = 85
                        send_motor_command("left", 85)
                else:
                    if safe_direction == "forward":
                        print(f"Person ({person_confidence:.2f}) - Moving forward")
                        action = "forward"
                        speed = 100
                        send_motor_command("forward", 100)
                    else:
                        print("Person centered but obstacle - Stopping")
                        action = "stop"
                        send_motor_command("stop")
        else:
            if safe_direction == "forward":
                print("No follow mode - Moving forward slowly")
                action = "forward"
                speed = 30
                send_motor_command("forward", 30)
            elif safe_direction == "left":
                print("No follow mode - Turning left to avoid obstacle")
                action = "left"
                speed = 85
                send_motor_command("left", 85)
            elif safe_direction == "right":
                print("No follow mode - Turning right to avoid obstacle")
                action = "right"
                speed = 85
                send_motor_command("right", 85)
            else:
                print("No follow mode and obstacle - Stopping")
                action = "stop"
                send_motor_command("stop")

        # Log command
        commands.append((action, speed))

        # Visualize obstacle detection
        if obstacle_mask is not None:
            height, width = obstacle_mask.shape
            grid_height = height // GRID_ROWS
            grid_width = width // GRID_COLS
            
            for i in range(1, GRID_ROWS):
                cv2.line(frame, (0, i * grid_height), (width, i * grid_height), (0, 255, 255), 1)
            for j in range(1, GRID_COLS):
                cv2.line(frame, (j * grid_width, 0), (j * grid_width, height), (0, 255, 255), 1)
            
            obstacle_display = cv2.cvtColor(obstacle_mask, cv2.COLOR_GRAY2BGR)
            frame = cv2.addWeighted(frame, 0.7, obstacle_display, 0.3, 0)
            
            cv2.putText(frame, f"Safe: {safe_direction}", (10, 110),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

        # Calculate latency
        latency = (time.time() - start_time) * 1000  # in ms
        frame_times.append(latency)

        # Log metrics
        metrics_log.append({
            "frame": frame_number,
            "fps": fps,
            "latency_ms": latency,
            "person_iou": person_iou,
            "gesture_correct": gesture_correct,
            "obstacle_iou": obstacle_iou,
            "distance_error": distance_error,
            "follow_mode": int(follow_mode)
        })

        # Display metrics
        cv2.putText(frame, f"FPS: {fps:.2f}", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        cv2.putText(frame, f"Person: {person_confidence:.2f}", (10, 50),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        cv2.putText(frame, f"Gesture: {gesture} ({gesture_confidence:.2f})", (10, 85),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        cv2.putText(frame, f"Follow: {'ON' if follow_mode else 'OFF'}", (10, 90),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0) if follow_mode else (0, 0, 255), 1)
        cv2.putText(frame, f"PersonIoU: {person_iou:.2f}", (10, 130),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        cv2.putText(frame, f"GestureOK: {gesture_correct}", (10, 150),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        cv2.putText(frame, f"ObsIoU: {obstacle_iou:.2f}", (10, 185),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        cv2.putText(frame, f"DistErr: {distance_error:.1f}", (10, 190),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        cv2.putText(frame, f"Latency: {latency:.1f}ms", (10, 210),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

        # Show frame
        cv2.imshow("Frame", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        frame_number += 1

except KeyboardInterrupt:
    print("Shutting down...")
finally:
    send_motor_command("stop")
    hands.close()
    cap.release()
    cv2.destroyAllWindows()

    # Save metrics to CSV
    metrics_df = pd.DataFrame(metrics_log)
    metrics_df.to_csv(log_file, index=False)

    # Calculate command stability
    command_changes = 0
    for i in range(1, len(commands)):
        if commands[i] != commands[i-1]:
            command_changes += 1
    command_stability = command_changes / len(commands) if commands else 0

    # Calculate gesture accuracy
    gesture_accuracy = metrics_df['gesture_correct'].mean() * 100 if not metrics_df.empty else 0

    # Print summary
    print("\n=== Evaluation Metrics Summary ===")
    print(f"Total Frames: {frame_number}")
    print(f"Average FPS: {metrics_df['fps'].mean():.2f}")
    print(f"Average Latency: {metrics_df['latency_ms'].mean():.2f} ms")
    print(f"Gesture Accuracy: {gesture_accuracy:.2f}%")
