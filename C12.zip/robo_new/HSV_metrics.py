import cv2
import numpy as np
import socket
import json
import time
import pandas as pd
from uuid import uuid4

# HSV color range for green/maroon
HSV_LOWER = np.array([17, 76, 102])
HSV_UPPER = np.array([27, 204, 230])

# Socket setup for motor commands
PI_IP = "192.168.142.130"
PI_PORT = 65432

# Camera setup
STREAM_URL = 'http://192.168.142.130:8080/?action=stream'
cap = cv2.VideoCapture(STREAM_URL)
if not cap.isOpened():
    print("Error: Could not open video stream")
    exit()

cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

# Metrics logging
metrics_log = []
frame_times = []
positions = []  # For jerk calculation
log_file = f"metrics_{uuid4()}.csv"

# Simulated ground truth for IoU (replace with actual annotations)
# Format: {frame_number: (x, y, w, h)}
ground_truth = {
    0: (200, 150, 100, 100),
    100: (220, 160, 100, 100),
    200: (210, 155, 100, 100),
    # Add more as needed
}

def calculate_iou(box1, box2):
    """Calculate IoU between two bounding boxes (x, y, w, h)."""
    x1, y1, w1, h1 = box1
    x2, y2, w2, h2 = box2
    
    xi1 = max(x1, x2)
    yi1 = max(y1, y2)
    xi2 = min(x1 + w1, x2 + w2)
    yi2 = min(y1 + h1, y2 + h2)
    
    inter_area = max(0, xi2 - xi1) * max(0, yi2 - yi1)
    box1_area = w1 * h1
    box2_area = w2 * h2
    union_area = box1_area + box2_area - inter_area
    
    return inter_area / union_area if union_area > 0 else 0

def send_motor_command(action, speed=None):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((PI_IP, PI_PORT))
            cmd = {"action": action}
            if speed:
                cmd["speed"] = speed
            s.sendall((json.dumps(cmd) + '\n').encode())
            response = s.recv(1024).decode()
            return response == "ACK"
    except Exception as e:
        print(f"Socket error: {e}")
        return False

def hsv_tuner():
    cap = cv2.VideoCapture(STREAM_URL)
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        cv2.imshow("Frame", frame)
        def mouse_callback(event, x, y, flags, param):
            if event == cv2.EVENT_LBUTTONDOWN:
                print(f"HSV at ({x}, {y}): {hsv[y, x]}")
        cv2.setMouseCallback("Frame", mouse_callback)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cap.release()
    cv2.destroyAllWindows()

# Main processing loop
try:
    last_time = time.time()
    frame_count = 0
    fps = 0
    frame_number = 0

    while True:
        start_time = time.time()
        ret, frame = cap.read()
        if not ret:
            print("Failed to grab frame")
            time.sleep(0.1)
            continue

        # Calculate FPS
        frame_count += 1
        current_time = time.time()
        if current_time - last_time >= 1.0:
            fps = frame_count / (current_time - last_time)
            frame_count = 0
            last_time = current_time

        # Convert frame to HSV
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # Create mask for red (combine both ranges)
        mask1 = cv2.inRange(hsv, HSV_LOWER, HSV_UPPER)
        mask2 = cv2.inRange(hsv, HSV_LOWER, HSV_UPPER)
        mask = cv2.bitwise_or(mask1, mask2)

        # Reduce noise
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

        # Find contours
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # Initialize bounding box
        bbox = None
        max_area = 0
        frame_width = frame.shape[1]
        frame_height = frame.shape[0]

        # Find largest contour
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > max_area and area > 500:
                max_area = area
                x, y, w, h = cv2.boundingRect(contour)
                bbox = (x, y, w, h)

        # Process bounding box and control motors
        iou = 0
        distance_error = 0
        center_x, center_y = frame_width // 2, frame_height // 2

        if bbox:
            x, y, w, h = bbox
            center_x = x + w // 2
            center_y = y + h // 2

            # Draw bounding box and center
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.circle(frame, (center_x, center_y), 5, (0, 0, 255), -1)

            # Calculate IoU if ground truth exists
            if frame_number in ground_truth:
                iou = calculate_iou(bbox, ground_truth[frame_number])

            # Calculate distance error
            target_center = (frame_width // 2, frame_height // 2)
            distance_error = np.sqrt((center_x - target_center[0])**2 + (center_y - target_center[1])**2)

            # Store position for jerk calculation
            positions.append((center_x, center_y))

            # Motor control
            left_threshold = frame_width // 3
            right_threshold = 2 * frame_width // 3

            if center_x < left_threshold:
                print("Turning left")
                send_motor_command("left", 85)
            elif center_x > right_threshold:
                print("Turning right")
                send_motor_command("right", 85)
            else:
                print("Moving forward")
                send_motor_command("forward", 60)
        else:
            print("No red detected, stopping")
            send_motor_command("stop")

        # Calculate latency
        latency = (time.time() - start_time) * 1000  # in ms
        frame_times.append(latency)

        # Log metrics
        metrics_log.append({
            "frame": frame_number,
            "fps": fps,
            "latency_ms": latency,
            "iou": iou,
            "distance_error": distance_error,
            "center_x": center_x,
            "center_y": center_y
        })
        if frame_number in ground_truth:
            print(f"Frame: {frame_number}, Accuracy (IoU): {iou * 100:.2f}%")
        # Display metrics on frame
        cv2.putText(frame, f"FPS: {fps:.2f}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        cv2.putText(frame, f"Latency: {latency:.2f} ms", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        cv2.putText(frame, f"IoU: {iou:.2f}", (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        cv2.putText(frame, f"Dist Error: {distance_error:.2f}", (10, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

        # Display frames
        cv2.imshow("Frame", frame)
        cv2.imshow("Mask", mask)

        # Break on 'q'
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        frame_number += 1

except KeyboardInterrupt:
    print("Shutting down...")
finally:
    send_motor_command("stop")
    cap.release()
    cv2.destroyAllWindows()

    # Save metrics to CSV
    metrics_df = pd.DataFrame(metrics_log)
    metrics_df.to_csv(log_file, index=False)

    # Calculate jerk
    if len(positions) > 3:
        dt = 1 / fps if fps > 0 else 0.033  # Assume 30 fps if fps is 0
        positions = np.array(positions)
        velocity = np.diff(positions, axis=0) / dt
        acceleration = np.diff(velocity, axis=0) / dt
        jerk = np.diff(acceleration, axis=0) / dt
        jerk_magnitude = np.mean(np.sqrt(jerk[:, 0]**2 + jerk[:, 1]**2))
    else:
        jerk_magnitude = 0

    # Print summary
    print("\n=== Evaluation Metrics Summary ===")
    print(f"Average FPS: {metrics_df['fps'].mean():.2f}")
    print(f"Average Latency: {metrics_df['latency_ms'].mean():.2f} ms")
    for entry in metrics_log:
        if entry["frame"] in ground_truth:
            print(f"Frame: {entry['frame']}, Accuracy: {entry['iou'] * 100:.2f}%")